#!/bin/bash
# ============================================================
#   SCRIPT DE INSTALAÇÃO AUTOMÁTICA
#   Sistema de Calls de Investimento
# ============================================================

set -e  # Para se houver erro

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   INSTALAÇÃO DO SISTEMA DE CALLS v1.0        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Verifica se Python 3 está instalado
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado!"
    echo "   Instale em: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1)
echo "✅ Python encontrado: $PYTHON_VERSION"

# Verifica se pip está disponível
if ! command -v pip3 &> /dev/null && ! command -v pip &> /dev/null; then
    echo "❌ pip não encontrado!"
    echo "   Execute: python3 -m ensurepip --upgrade"
    exit 1
fi

PIP_CMD="pip3"
if ! command -v pip3 &> /dev/null; then
    PIP_CMD="pip"
fi

echo "📦 Instalando dependências..."
$PIP_CMD install -r requirements.txt --quiet

echo ""
echo "✅ Dependências instaladas com sucesso!"
echo ""

# Cria os diretórios necessários
mkdir -p logs data src

# Cria o __init__.py na pasta src
touch src/__init__.py

echo "📁 Estrutura de pastas criada"
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║              PRÓXIMOS PASSOS                 ║"
echo "╠══════════════════════════════════════════════╣"
echo "║                                              ║"
echo "║  1. Abra o arquivo config.py                 ║"
echo "║  2. Preencha seu número WhatsApp             ║"
echo "║  3. Siga o guia para obter a API KEY         ║"
echo "║                                              ║"
echo "║  4. Teste com:                               ║"
echo "║     python3 main.py --teste                  ║"
echo "║                                              ║"
echo "║  5. Inicie o sistema:                        ║"
echo "║     python3 main.py                          ║"
echo "║                                              ║"
echo "║  Guia completo: GUIA_DE_CONFIGURACAO.md      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
